/* Cachea el armazón para que la app abra sin cobertura.
   Los JSON del repo NUNCA se cachean: siempre se piden frescos. */
const CACHE = "diario-v1";
const SHELL = ["./index.html", "./style.css", "./app.js", "./manifest.json"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys()
      .then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", e => {
  const url = new URL(e.request.url);
  if(e.request.method !== "GET") return;
  if(url.host === "api.github.com") return;          // siempre en directo

  // datos del viaje: red primero, cache de reserva
  if(url.pathname.includes("/data/")){
    e.respondWith(
      fetch(e.request)
        .then(r => {
          const copia = r.clone();
          caches.open(CACHE).then(c => c.put(e.request, copia));
          return r;
        })
        .catch(() => caches.match(e.request))
    );
    return;
  }

  // armazón: cache primero
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
